﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 1;
            while (a==1)
            {
                Console.WriteLine("stuck in a time loop all by yourself handsome?");
            }

        }
    }
}